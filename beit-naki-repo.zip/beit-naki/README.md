# הביתה! 🏠 (Habitah)

משחק הסדר המשפחתי — PWA בעברית (RTL) שהופך סידור הבית לתחרות משפחתית.
שחקנים צוברים כוכבים, ההורים מאשרים, ויש לוח אלופים, רמות, רצפים ופרסים.

**חי באוויר:** https://beit-naki.netlify.app
**גרסה:** v93

## מבנה
| קובץ | תיאור |
|------|-------|
| `index.html` | כל האפליקציה (UI + לוגיקה + אפקטים) |
| `sw.js` | Service Worker (התקנה + עבודה offline) |
| `manifest.json` | הגדרות PWA |
| `icons/` | אייקוני האפליקציה |

## תשתית
- **Backend:** Supabase (סנכרון משפחתי לפי קוד משפחה, RLS + RPC). בצד-לקוח נמצא רק ה-publishable key — בטוח לחשיפה.
- **Deploy:** Netlify (site: `beit-naki`).

## עדכון האתר החי
מעלים את הקבצים מחדש ל-Netlify (אותו site). ה-SW עובד network-first, אז גרסה חדשה נטענת מיד כשיש אינטרנט. לעדכון יש להעלות את `APP_VERSION` ב-index.html ואת מספר ה-cache ב-sw.js.
